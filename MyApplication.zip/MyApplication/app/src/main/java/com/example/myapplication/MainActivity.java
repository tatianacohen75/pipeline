package com.example.myapplication;

import android.view.View;
import  android.widget.Toast;
import android.widget.Button;
import android.content.Intent;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button=(Button) findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View argO) {
                Toast.makeText(MainActivity.this, "Hello button2 !", Toast.LENGTH_SHORT).show();
            }
        });

        Button button4=(Button) findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View argO) {
                Intent intent2= new Intent(MainActivity.this, MainActivity2.class);
                intent2.putExtra("my message", "tu a tape sur le boutton 4");
                startActivity(intent2);
            }
        });
    }

    public void affiche(View view) {
        Toast.makeText(this, "Hello button1", Toast.LENGTH_SHORT).show();

    }

    public void sendMessage(View view){
        Intent intent = new Intent(this, MainActivity2.class);
        EditText editText=(EditText) findViewById(R.id.myEditText1);
        String message = editText.getText().toString();
        intent.putExtra("my message", message);
        startActivity(intent);
    }

    public void sendMessageTotoResult(View view){
        Intent intent= new Intent(this, MainActivity2.class);
        startActivityForResult(intent,2);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode==2)
        {
            String message=data.getStringExtra("message");
            EditText etext=(EditText) findViewById(R.id.myEditText1);
            etext.setText(message);
        }
    }
}
