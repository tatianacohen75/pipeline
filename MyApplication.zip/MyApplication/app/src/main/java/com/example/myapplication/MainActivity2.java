package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;

import android.os.Bundle;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent intent= getIntent();
        String msg = intent.getStringExtra("my message");

        TextView tV2= (TextView) findViewById(R.id.textView2);
        tV2.setText(msg+ "activite2");

        Button button=(Button) findViewById(R.id.button6);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View argO) {
                EditText editText=(EditText) findViewById(R.id.editText);
                String messg = editText.getText().toString();

                Intent intent2=new Intent();
                intent2.putExtra("message", messg);
                setResult(2, intent2);
                finish();
            }
        });
    }
}