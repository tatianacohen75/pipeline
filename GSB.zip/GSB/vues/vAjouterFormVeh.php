
<img  src="images/GSBlogo.png" alt="logo gsb" align = left hspace ="0"/>

<script type="text/javascript">

</script>

<!--Saisie des informations dans un formulaire!-->
<div class="container">

<form name="formAjout" action="" method="post" onSubmit="return valider()">
  <fieldset>
    <legend>Entrez les donn&#233;es du v&#233;hicule &agrave; ajouter </legend>
    
    <label>identifiant :</label> <input type="text" name="id" size="20" /><br />
    <label>marque:</label> <input type="text" name="marq" size="10" /><br />
    <label>mod&egrave;le:</label> <input type="text" name="mod" size="10" /><br />
    <label>couleur :</label> <input type="text" name="couleur" size="10" /><br />
    <label>km :</label> <input type="text" name="km" size="10" /><br />
    <label>type d'essence :</label> <input type="text" name="typeessence" size="10" /><br />
    <label>plein :</label> <input type="text" name="plein" size="10" /><br />
    <label>d&#233;fauts:</label> <input type="text" name="defauts" size="10" /><br />
    

  </fieldset>
  <button type="submit" class="btn btn-primary">Enregistrer</button>
  <button type="reset" class="btn">Annuler</button>
  <p />
</form>
</div>


