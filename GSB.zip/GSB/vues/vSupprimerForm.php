<img  src="images/GSBlogo.png" alt="logo gsb" align = left hspace ="0"/>

<!--Formulaire de suppression à partir de l'identifiant -->

<div class="container">

<form action="" method=post>
<fieldset>
<legend>Entrez la matricule du visiteur &agrave; supprimer </legend>
<label>Matricule:</label>
       <input type="text" name="Mat" size="10" /><br />
</fieldset>
<button type="submit" class="btn btn-primary">Supprimer</button>
<button type="reset" class="btn">Annuler</button>
</form>

</div>
