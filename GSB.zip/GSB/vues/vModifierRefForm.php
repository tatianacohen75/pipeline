<img  src="images/GSBlogo.png" alt="logo gsb" align = left hspace ="0"/>

<!--Saisie des informations dans un formulaire!-->
<div class="container">

<form name="formAjout" action="" method="post" onSubmit="return valider()">
  <fieldset>
    <legend>Entrez les donn�es sur le visiteur &agrave; modifier </legend>
    <label> Matricule : </label> <input type="text" name="mat" size="10" /><br />
  </fieldset>
  <button type="submit" class="btn btn-primary">Enregistrer</button>
  <button type="reset" class="btn">Annuler</button>
  <p />
</form>
</div>