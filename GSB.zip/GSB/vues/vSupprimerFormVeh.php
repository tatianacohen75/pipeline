<img  src="images/GSBlogo.png" alt="logo gsb" align = left hspace ="0"/>

<!--Formulaire de suppression à partir de l'identifiant -->

<div class="container">

<form action="" method=post>
<fieldset>
<legend>Entrez l'identifiant du v&#233;hicule &agrave; supprimer </legend>
<label>identifiant:</label>
       <input type="text" name="id" size="10" /><br />
</fieldset>
<button type="submit" class="btn btn-primary">Supprimer</button>
<button type="reset" class="btn">Annuler</button>
</form>

</div>
