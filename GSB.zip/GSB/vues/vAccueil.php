 <!-- 
<div class="jumbotron masthead">
  <div class="container"> -->
 <!--    <h1>Les lentilles</h1>
    <img src="images/lentille.jpg" />
    <hr>
    <p>La vision a l'etat pur.</p>
  </div>
satisfait ou rembourse
</div> -->


<div id="my_carousel" class="carousel slide" data-ride="carousel">
<!-- Bulles -->
<ol class="carousel-indicators">
<li data-target="#my_carousel" data-slide-to="" class="active"></li>

</ol>
<!-- Slides -->
<div class="carousel-inner">
<!-- Page 1 -->
<div class="item active">  
<div class="carousel-page">


<img src="images/vehicules.jpg" class="img-responsive" style="margin:600px width:1010%;
height:1020px ;" />
</div> 
<div class="carousel-caption"style="color: #FFFFFF;">Emprunte pour mieux travailler!</div>
</div>   
<!-- Page 2 -->
<div class="item"> 
<div class="carousel-page"><img src="images/devanturedumag" class="img-responsive img-rounded" 
style="margin:1800px width:800%;
height:880px;"  /></div> 
<div class="carousel-caption"style="color: #FFFFFF;">Contactez nous !</div>
</div>
<div class="item"> 
<div class="carousel-page"><img src="images/lentilleelsah" class="img-responsive img-rounded" 
style="margin:1800px width:800%;
height:880px;"  /></div> 
<div class="carousel-caption"style="color: #FFFFFF;">Contactez nous !</div>
</div>
</div>   

<!-- div class="item">  
<div class="carousel-page">
<img src="images/lentille.jpg" class="img-responsive img-rounded" 
style="margin:0px auto;max-height:100%;"  />
</div>  
<div class="carousel-caption">Vous serez Satisfait!</div>
</div>   -->   
</div>

<a class="left carousel-control" href="#my_carousel" data-slide="prev">
<span class="glyphicon glyphicon-chevron-left"></span>
</a>
<a class="right carousel-control" href="#my_carousel" data-slide="next">
<span class="glyphicon glyphicon-chevron-right"></span>
</a> 


<style>
.carousel-page
{
width:380%;
height:720px;
background-color:#5f666d;
color:white;
}
</style>



