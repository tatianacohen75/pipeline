<img  src="images/GSBlogo.png" alt="logo gsb" align = left hspace ="0"/>

<!--Formulaire de recherche à partir du nom-->

<div class="container">
  <form class="form-search" action="" method=post>
    <legend>Entrez l'identifiant de la panne &agrave; rechercher</legend>
    <div class="input-append">
      <input type="text" class="input-medium search-query" name="idPanne">
      <button type="submit" class="btn btn-primary">Rechercher</button>
    </div>
  </form>
</div>
