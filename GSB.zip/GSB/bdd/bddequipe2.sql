-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Dim 13 Septembre 2020 à 11:30
-- Version du serveur :  5.7.11
-- Version de PHP :  5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `bddequipe2`
--

-- --------------------------------------------------------

--
-- Structure de la table `labo`
--

CREATE TABLE `labo` (
  `labCode` int(2) NOT NULL,
  `labNom` varchar(10) NOT NULL,
  `labChefvente` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `labo`
--

INSERT INTO `labo` (`labCode`, `labNom`, `labChefvente`) VALUES
(1, 'Laboderm', 'joseph'),
(2, 'LaboJaures', 'mathias'),
(3, 'LaboLac', 'Paul'),
(4, 'LaboPantin', 'Sarah'),
(5, 'Panpharma', 'Alex'),
(6, 'BioGroup', 'Jean');

-- --------------------------------------------------------

--
-- Structure de la table `region`
--

CREATE TABLE `region` (
  `regCode` int(2) NOT NULL,
  `secCode` int(1) NOT NULL,
  `regNom` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `region`
--

INSERT INTO `region` (`regCode`, `secCode`, `regNom`) VALUES
(2, 5, 'Guyanne'),
(6, 6, 'Mayotte'),
(11, 1, 'Ile de France'),
(22, 3, 'Picardie'),
(72, 7, 'Martinique'),
(73, 2, 'Savoie'),
(85, 4, 'Vendée');

-- --------------------------------------------------------

--
-- Structure de la table `secteur`
--

CREATE TABLE `secteur` (
  `secCode` int(1) NOT NULL,
  `secLibelle` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `secteur`
--

INSERT INTO `secteur` (`secCode`, `secLibelle`) VALUES
(7, 'DTOMaa'),
(6, 'DTOMca'),
(5, 'Est'),
(3, 'Nord'),
(4, 'Ouest'),
(1, 'ParisCentre'),
(2, 'Sud');

-- --------------------------------------------------------

--
-- Structure de la table `travailler`
--

CREATE TABLE `travailler` (
  `visMatricule` int(10) NOT NULL,
  `JJMMAA` datetime NOT NULL,
  `regCode` int(2) NOT NULL,
  `traRole` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `travailler`
--

INSERT INTO `travailler` (`visMatricule`, `JJMMAA`, `regCode`, `traRole`) VALUES
(1123456789, '2015-09-17 13:12:24', 22, 'Visiteur'),
(1234567889, '2018-10-17 13:11:38', 72, 'Visiteur'),
(1234567899, '2020-09-10 13:10:51', 11, 'Visiteur');

-- --------------------------------------------------------

--
-- Structure de la table `visiteur`
--

CREATE TABLE `visiteur` (
  `visMatricule` int(10) NOT NULL,
  `visNom` varchar(25) NOT NULL,
  `visPrenom` varchar(50) NOT NULL,
  `visAdresse` varchar(50) NOT NULL,
  `visCp` varchar(5) NOT NULL,
  `visVille` varchar(30) NOT NULL,
  `visDateEmbauche` datetime NOT NULL,
  `secCode` int(1) NOT NULL,
  `laboCode` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `visiteur`
--

INSERT INTO `visiteur` (`visMatricule`, `visNom`, `visPrenom`, `visAdresse`, `visCp`, `visVille`, `visDateEmbauche`, `secCode`, `laboCode`) VALUES
(1123456789, 'Poney', 'Eva', '23 Bd Serrurier', '75019', 'Paris', '2020-11-10 10:18:22', 1, 3),
(1234567889, 'Koskas', 'Alexandra', '112 Rue Manin', '75019', 'Paris', '2017-09-11 13:13:56', 1, 2),
(1234567899, 'Arejouane', 'Naomie', '106 Rue Petit', '75019', 'Paris', '2016-08-17 13:13:14', 1, 1);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `labo`
--
ALTER TABLE `labo`
  ADD PRIMARY KEY (`labCode`);

--
-- Index pour la table `region`
--
ALTER TABLE `region`
  ADD PRIMARY KEY (`regCode`),
  ADD KEY `secCode` (`secCode`);

--
-- Index pour la table `secteur`
--
ALTER TABLE `secteur`
  ADD PRIMARY KEY (`secCode`),
  ADD KEY `secLibelle` (`secLibelle`);

--
-- Index pour la table `travailler`
--
ALTER TABLE `travailler`
  ADD PRIMARY KEY (`visMatricule`),
  ADD KEY `regCode` (`regCode`);

--
-- Index pour la table `visiteur`
--
ALTER TABLE `visiteur`
  ADD PRIMARY KEY (`visMatricule`),
  ADD KEY `secCode` (`secCode`),
  ADD KEY `laboCode` (`laboCode`);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `region`
--
ALTER TABLE `region`
  ADD CONSTRAINT `region_ibfk_1` FOREIGN KEY (`secCode`) REFERENCES `secteur` (`secCode`);

--
-- Contraintes pour la table `travailler`
--
ALTER TABLE `travailler`
  ADD CONSTRAINT `travailler_ibfk_1` FOREIGN KEY (`visMatricule`) REFERENCES `visiteur` (`visMatricule`),
  ADD CONSTRAINT `travailler_ibfk_2` FOREIGN KEY (`regCode`) REFERENCES `region` (`regCode`);

--
-- Contraintes pour la table `visiteur`
--
ALTER TABLE `visiteur`
  ADD CONSTRAINT `visiteur_ibfk_1` FOREIGN KEY (`laboCode`) REFERENCES `labo` (`labCode`),
  ADD CONSTRAINT `visiteur_ibfk_2` FOREIGN KEY (`secCode`) REFERENCES `secteur` (`secCode`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
